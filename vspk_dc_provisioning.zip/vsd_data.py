### VSD access data

vsd_api_url = 'https://localhost:8443'
vsd_api_username = 'csproot'
vsd_api_password = 'csproot'
vsd_api_csp = 'csp'

### VSD CBIS L2 domain variables
cbis_enterprise_name = 'CBIS-Infrastructure-Enterprise'
l2_domain_template_name = 'L2 Domain Template'